#!/usr/bin/env python

from time import sleep
import sys

with open("root.txt") as f:
    flag = f.read()

def compare_flag(input_flag):
    length = len(input_flag)
    if(length == 0):
        print "No"
        return False
    if(length > len(flag)):
        print "No"
        return False
    if input_flag.lower() == "exit":
        exit(1)
    for i in range(length):
        if input_flag[i] != flag[i]:
            print "No"
            return False
    if input_flag != flag:
        print "Yes"
    else:
        print "Congratulations"
        exit(0)
    return True

for i in range(0x10000):
    sys.stdout.write("> ")
    sys.stdout.flush()
    input_flag = raw_input()
    compare_flag(input_flag)
