exec 3<>/dev/tcp/dobby.cybergym.lucideus.in/4002
for j in {1..50}
do
 for i in $(cat dic.txt)
 do
   echo $x$i >&3
   result=$(timeout 0.1 cat <&3)
   if [[ $result == *"Yes"* ]] || [[ $result == *"Congratulations"* ]]
   then
       x=$x$i
       echo $x
   else
       continue
   fi
 done
done
