#!/usr/bin/env python3
import socketserver

HEADER = """\
XXXXXXXXXXXXXXXXXXXXXXX
X     ABRACADABRA     X
XXXXXXXXXXXXXXXXXXXXXXX
 \n"""

MESSAGE = 'October_arrived,_spreading_a_damp_chill_over_the_grounds_and_into_the_castle._Madam_Pomfrey,_the_nurse,_was_kept_busy_by_a_sudden_spate_of_colds_among_the_staff_and_students._Her_Pepperup_potion_worked_instantly,_though_it_left_the_drinker_smoking_at_the_ears_for_several_hours_afterward._Ginny_Weasley,_who_had_been_looking_pale,_was_bullied_into_taking_some_by_Percy._The_steam_pouring_from_under_her_vivid_hair_gave_the_impression_that_her_whole_head_was_on_fire._Raindrops_the_size_of_bullets_thundered_on_the_castle_windows_for_days_on_end;_the_lake_rose,_the_flower_beds_turned_into_muddy_streams,_and_Hagrids_pumpkins_swelled_to_the_size_of_garden_sheds._Oliver_Woods_enthusiasm_for_regular_training_sessions,_however,_was_not_dampened,_which_was_why_Harry_was_to_be_found,_late_one_stormy_Saturday_afternoon_a_few_days_before_Halloween,_returning_to_Gryffindor_Tower,_drenched_to_the_skin_and_splattered_with_mud._Even_aside_from_the_rain_and_wind_it_hadnt_been_a_happy_practice_session._Fred_and_George,_who_had_been_spying_on_the_Slytherin_team,_had_seen_for_themselves_the_speed_of_those_new_Nimbus_Two_Thousand_and_Ones._They_reported_that_the_Slytherin_team_was_no_more_than_seven_greenish_blurs,_shooting_through_the_air_like_missiles._As_Harry_squelched_along_the_deserted_corridor_he_came_across_somebody_who_looked_just_as_preoccupied_as_he_was._Nearly_Headless_Nick,_the_ghost_of_Gryffindor_Tower,_was_staring_morosely_out_of_a_window,_muttering_under_his_breath,_"._._._dont_fulfill_their_requirements_._._._half_an_inch,_if_that_._._."_"Hello,_Nick,"_said_Harry._"Hello,_hello,"_said_Nearly_Headless_Nick,_starting_and_looking_round._He_wore_a_dashing,_plumed_hat_on_his_long_curly_hair,_and_a_tunic_with_a_ruff,_which_concealed_the_fact_that_his_neck_was_almost_completely_severed._He_was_pale_as_smoke,_and_Harry_could_see_right_through_him_to_the_cygym{dark_sky_and_torrential_rain_outside}._"You_look_troubled,_young_Potter,"_said_Nick,_folding_a_transparent_letter_as_he_spoke_and_tucking_it_inside_his_doublet._"So_do_you,"_said_Harry._"Ah,"_Nearly_Headless_Nick_waved_an_elegant_hand,_"a_matter_of_no_importance._._._._Its_not_as_though_I_really_wanted_to_join._._._._Thought_Id_apply,_but_apparently_I_dont_fulfill_requirements_-"_In_spite_of_his_airy_tone,_there_was_a_look_of_great_bitterness_on_his_face._"But_you_would_think,_wouldnt_you,"_he_erupted_suddenly,_pulling_the_letter_back_out_of_his_pocket,_"that_getting_hit_forty-five_times_in_the_neck_with_a_blunt_axe_would_qualify_you_to_join_the_Headless_Hunt?"_"Oh_-_yes,"_said_Harry,_who_was_obviously_supposed_to_agree._"I_mean,_nobody_wishes_more_than_I_do_that_it_had_all_been_quick_and_clean,_and_my_head_had_come_off_properly,_I_mean,_it_would_have_saved_me_a_great_deal_of_pain_and_ridicule._However_-"_Nearly_Headless_Nick_shook_his_letter_open_and_read_furiously:_"We_can_only_accept_huntsmen_whose_heads_have_parted_company_with_their_bodies._You_will_appreciate_that_it_would_be_impossible_otherwise_for_members_to_participate_in_hunt_activities_such_as_Horseback_Head-Juggling_and_Head_Polo._It_is_with_the_greatest_regret,_therefore,_that_I_must_inform_you_that_you_do_not_fulfill_our_requirements._With_very_best_wishes,_Sir_Patrick_Delaney-Podmore."_Fuming,_Nearly_Headless_Nick_stuffed_the_letter_away._"Half_an_inch_of_skin_and_sinew_holding_my_neck_on,_Harry!_Most_people_would_think_thats_good_and_beheaded,_but_oh,_no,_its_not_enough_for_Sir_Properly_Decapitated-Podmore."_Nearly_Headless_Nick_took_several_deep_breaths_and_then_said,_in_a_far_calmer_tone,_"So_-_whats_bothering_you?_Anything_I_can_do?"_"No,"_said_Harry._"Not_unless_you_know_where_we_can_get_seven_free_Nimbus_Two_Thousand_and_Ones_for_our_match_against_Sly..."'
HOST = '0.0.0.0'
PORT = 4001


class ThreadedTCPRequestHandler(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(HEADER.encode("utf-8"))
        print(f"New connection from {self.client_address[0]} on port {self.client_address[1]}")
        for char in MESSAGE:
            self.wfile.write(f"{char}\n".encode("utf-8"))
            data = self.rfile.readline().strip()
            if (data.decode("utf-8")) != char:
                self.wfile.write(f"Invalid response\n".encode("utf-8"))
                self.request.close()
                break


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":
    server = ThreadedTCPServer((HOST, PORT), ThreadedTCPRequestHandler)
    with server:
        server.serve_forever()
