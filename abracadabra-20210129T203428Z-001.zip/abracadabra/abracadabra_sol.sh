exec 3<>/dev/tcp/127.0.0.1/2345
ans1=$(timeout 0.01 cat <&3)
ans1=$(echo "${ans1: -1}")
echo $ans1 >&3
echo -n $ans1
for i in {1..99}
do
   ans2=$(timeout 0.01 cat <&3)
   echo $ans2 >&3
   echo -n $ans2
done
